mkdir ~/mobs/
cp bin/mobs ~/mobs

echo install done
